from django.contrib import admin
from .models import Week, Class

admin.site.register(Week)
admin.site.register(Class)
