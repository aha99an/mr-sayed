from django.apps import AppConfig


class LecturesConfig(AppConfig):
    name = 'lectures'
